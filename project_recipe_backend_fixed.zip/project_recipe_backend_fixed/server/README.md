# Recipe Backend API

## Spuštění projektu

```bash
npm install
npm start
```

Server běží na:

```bash
http://localhost:8888
```

## Funkcionality

### 1. Vytvoření suroviny
POST `/ingredient/create`

```json
{
  "name": "Rajče"
}
```

### 2. Výpis surovin
GET `/ingredient/list`

### 3. Vytvoření receptu
POST `/recipe/create`

```json
{
  "title": "Těstoviny",
  "description": "Jednoduché těstoviny",
  "instructions": "Smíchat a uvařit",
  "ingredientIds": ["ingredient-id"]
}
```

### 4. Detail receptu
GET `/recipe/get?id=recipe-id`

### 5. Výpis receptů podle surovin
GET `/recipe/list?ingredientIds=id1,id2`

### 6. Smazání receptu
DELETE `/recipe/delete`

```json
{
  "id": "recipe-id"
}
```

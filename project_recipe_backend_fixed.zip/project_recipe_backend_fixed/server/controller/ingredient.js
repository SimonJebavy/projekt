const express = require('express');
const router = express.Router();

const ListAbl = require('../abl/ingredient/listAbl');
const CreateAbl = require('../abl/ingredient/createAbl');

router.get('/list', ListAbl);
router.post('/create', CreateAbl);

module.exports = router;

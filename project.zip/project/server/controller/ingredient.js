const express = require("express");
const router = express.Router();

const ListAbl = require("../abl/ingredients/listAbl");
const CreateAbl = require("../abl/ingredients/createAbl");
const DeleteAbl = require("../abl/ingredients/deleteAbl");

router.get("/list", ListAbl);
router.post("/create", CreateAbl);
router.post("/delete", DeleteAbl);

module.exports = router;

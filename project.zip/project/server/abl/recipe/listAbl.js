const recipeDao = require("../../dao/recipe-dao.js");
const ingredientDao = require("../../dao/ingredient-dao.js");

async function ListAbl(req, res) {
    try {
        const recipeList = recipeDao.list();

        // attach ingredient objects to each recipe
        const recipeListWithIngredients = recipeList.map((recipe) => ({
            ...recipe,
            ingredients: recipe.ingredientIds.map((id) =>
                ingredientDao.get(id),
            ),
        }));

        res.json({
            itemList: recipeListWithIngredients,
        });
    } catch (e) {
        console.error(e);

        res.status(500).json({
            message: e.message,
        });
    }
}

module.exports = ListAbl;

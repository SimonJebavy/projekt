const Ajv = require("ajv");
const ajv = new Ajv();

const recipeDao = require("../../dao/recipe-dao.js");
const ingredientDao = require("../../dao/ingredient-dao.js");

const schema = {
    type: "object",

    properties: {
        id: { type: "string" },
        title: { type: "string", maxLength: 50 },
        description: { type: "string", maxLength: 1000 },
        instructions: { type: "string", maxLength: 1000 },
        ingredientIds: {
            type: "array",
            items: { type: "string" },
            minItems: 1,
            maxItems: 20,
        },
    },

    required: ["id"],
    additionalProperties: false,
};

async function UpdateAbl(req, res) {
    try {
        let recipe = req.body;

        // validate input
        const valid = ajv.validate(schema, recipe);

        if (!valid) {
            res.status(400).json({
                code: "dtoInIsNotValid",
                message: "dtoIn is not valid",
                validationError: ajv.errors,
            });

            return;
        }

        // check if recipe exists
        const existingRecipe = recipeDao.get(recipe.id);

        if (!existingRecipe) {
            res.status(404).json({
                code: "recipeNotFound",
                message: `Recipe with id ${recipe.id} not found`,
            });

            return;
        }

        // check if all ingredientIds exist
        if (recipe.ingredientIds) {
            const missingIngredientIds = [];

            for (const ingredientId of recipe.ingredientIds) {
                const ingredient = ingredientDao.get(ingredientId);

                if (!ingredient) {
                    missingIngredientIds.push(ingredientId);
                }
            }

            if (missingIngredientIds.length > 0) {
                res.status(400).json({
                    code: "ingredientDoesNotExist",
                    message: `These ingredient ids do not exist: ${missingIngredientIds.join(", ")}`,
                });

                return;
            }
        }

        // update recipe
        const updatedRecipe = recipeDao.update(recipe);

        // attach ingredient objects
        updatedRecipe.ingredients = updatedRecipe.ingredientIds.map((id) =>
            ingredientDao.get(id),
        );

        // return dtoOut
        res.json(updatedRecipe);
    } catch (e) {
        console.error(e);

        res.status(500).json({
            message: e.message,
        });
    }
}

module.exports = UpdateAbl;
